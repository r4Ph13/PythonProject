import pygame as p
import random as r, ButtonPanel
import Variables
import Person

WIDTH = 700
HEIGHT = 700 #sizes
fps = Variables.FPS
def setup():
    global screen, clock
    p.init()
    screen = p.display.set_mode((WIDTH, HEIGHT))
    clock = p.time.Clock()
    p.display.set_caption("Shopping Simulation")
    icon = p.image.load('ShoppingSimulation/shoppingcart.png')
    p.display.set_icon(icon) #sets icon in the top left
def createGrid():
    grid = [] # 0 means ground, 1 means wall, 2 means shelf, 3 means checkout walls, 4 means checkout station
    for i in range(Variables.NUM_OF_SQUARES_X):
        l = []
        for j in range(Variables.NUM_OF_SQUARES_Y):
            if(i==0 or j==0 or i==Variables.NUM_OF_SQUARES_X-1 or (j==Variables.NUM_OF_SQUARES_Y-1 and i!=Variables.NUM_OF_SQUARES_X-2 and i!=Variables.NUM_OF_SQUARES_X-3)):
                l.append(1)
            else:
                l.append(0)
        grid.append(l)
    for i in range(3,Variables.NUM_OF_SQUARES_X-4):
        for j in range(3,Variables.NUM_OF_SQUARES_Y-2,3):
            grid[i][j] = 2
    grid[27][1] = 3
    grid[27][2] = 3
    grid[28][2] = 3
    grid[28][18] = 4
    return grid
def makePeople(num):
    peopleList = []
    for i in range(num):
        person = Person.Person(27,18)
        peopleList.append(person)
    return peopleList


def main():
    setup()
    peopleList = makePeople(Variables.NUM_OF_PEOPLE)
    buttons = ButtonPanel.drawButtons(screen)
    grid = createGrid()
    ButtonPanel.drawPanel(screen)
    done = False
    while not done:
        for event in p.event.get():
            if event.type == p.QUIT:
                done = True
        screen.fill('white')
        for i in range(len(grid)):
            for j in range(len(grid[i])):
                color = ()
                if(grid[i][j]==0 or grid[i][j]==4):
                    color = (255,255,255) if (i+j)%2==0 else (180,180,180)
                elif(grid[i][j]==1):
                    color = (0,0,0)
                elif(grid[i][j]==2):
                    color = (75,75,75)
                elif(grid[i][j]==3):
                    color = (164,116,73)
                p.draw.rect(screen, color, (i*Variables.SQ_LENGTH, j*Variables.SQ_LENGTH, Variables.SQ_LENGTH, Variables.SQ_LENGTH))
        cashier = p.draw.circle(screen, (255, 219, 172), (28*Variables.SQ_LENGTH+Variables.SQ_LENGTH//2, 1*Variables.SQ_LENGTH+Variables.SQ_LENGTH//2), Variables.SQ_LENGTH//2)
        # print(f"{len(peopleList)} esefsfes")
        for i in range(len(peopleList)):
            if(i>=len(peopleList)):
                break
            peopleList[i].draw(screen)
            shouldStay = peopleList[i].update(grid, [28,3], [28,18])
            if(not shouldStay):
                peopleList.pop(i)
                i-=1
        if(not r.randint(0,49)): # 1 in 50 chance for another customer to come in
            peopleList.append(Person.Person(27,18))
        ButtonPanel.drawButtons(screen)
        buttons = ButtonPanel.drawButtons(screen)
        p.display.flip()
        clock.tick(fps)
    p.quit()



if __name__ == "__main__":
    main()
