from Variables import *
import pygame as p
import random
TOTAL_MONEY = 0
CHECKOUT_TIME = 10
class Person():
    WIDTH = HEIGHT = SQ_LENGTH
    RADIUS = SQ_LENGTH//2
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.goHome = 0
        self.bordom = random.randint(PERSON_BOREDOM_RANGE[0],PERSON_BOREDOM_RANGE[1])
        self.money = random.randint(PERSON_MONEY_RANGE[0],PERSON_MONEY_RANGE[1])
        self.spent = 0
        self.checkingout = CHECKOUT_TIME
    def draw(self, screen):
        p.draw.circle(screen, 'red', (self.x*Person.WIDTH+Person.WIDTH//2, self.y*Person.HEIGHT+Person.HEIGHT//2), Person.RADIUS)
    def move(self, grid):
        possible = ['up', 'down', 'left', 'right']
        if(self.x==0 or grid[self.x-1][self.y]!=0):
            possible.remove('left')
        if(self.x==NUM_OF_SQUARES_X-1 or grid[self.x+1][self.y]!=0):
            possible.remove('right')
        if(self.y==0 or grid[self.x][self.y-1]!=0):
            possible.remove('up')
        if(self.y==NUM_OF_SQUARES_Y-1 or grid[self.x][self.y+1]!=0):
            possible.remove('down')
        move = random.choice(possible)
        if(move=='up'):
            self.y-=1
        elif(move=='down'):
            self.y+=1
        elif(move=='left'):
            self.x-=1
        elif(move=='right'):
            self.x+=1
    def moveToward(self, grid, point):
        possible = []
        x = point[0]-self.x
        y = point[1]-self.y
        if(x!=0):
            possible.append([self.x+(point[0]-self.x)//abs(point[0]-self.x), self.y])
        if(y!=0):
            possible.append([self.x, self.y+(point[1]-self.y)//abs(point[1]-self.y)])
        for i in range(len(possible)-1,-1,-1):
            if(grid[possible[i][0]][possible[i][1]]!=0 and grid[possible[i][0]][possible[i][1]]!=4):
                possible.pop(i)
        move = random.choice(possible)
        self.x = move[0]
        self.y = move[1]
    def lookAround(self,grid):
        possible = [[self.x+1,self.y], [self.x-1,self.y], [self.x,self.y+1], [self.x,self.y-1]]
        for i in range(len(possible)-1,-1,-1):
            if(not Person.withinBoundary(possible[i][0],possible[i][1]) or grid[possible[i][0]][possible[i][1]]!=2):
                possible.pop(i)
        if(len(possible)==0):
            return []
        else:
            return random.choice(possible)
    def withinBoundary(x, y):
        return x>=0 and y>=0 and x<NUM_OF_SQUARES_X and y<NUM_OF_SQUARES_Y
    def update(self, grid, cashier, end):
        global TOTAL_MONEY
        if(self.checkingout<CHECKOUT_TIME and self.checkingout!=0):
            self.checkingout-=1
        elif(self.goHome==0):
            if(random.randint(0,2)):
                shelf = self.lookAround(grid)
                if(len(shelf)!=0):
                    self.money-=COST # everything will be 5 dollars :/
                    self.spent+=COST
                else:
                    self.move(grid)
            else:
                self.move(grid)
            if(self.money<COST or self.bordom<=0):
                self.goHome = 1
            self.bordom-=1
        elif(self.goHome==1):
            self.moveToward(grid, cashier)
            if(self.x==cashier[0] and self.y==cashier[1]):
                self.checkingout -= 1
                self.goHome = 2
                TOTAL_MONEY+=self.spent
        elif(self.goHome==2):
            self.moveToward(grid,end)
            if(self.x==end[0] and self.y==end[1]):
                self.goHome = 3
        elif(self.goHome==3):
            self.goHome = 4
        elif(self.goHome==4):
            return False
        return True
